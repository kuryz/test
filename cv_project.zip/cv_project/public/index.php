<!DOCTYPE html>
<html>
<base href="/cv_project/">


<?php 
//define('base_path', $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']);
require_once '../app/init.php';
// echo base_path;
$app = new FjtRouter;

?>
</body>
<!-- jQuery Library -->
<script src="js/jquery-1.12.3.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/ripples.min.js"></script>
<script src="js/material.min.js"></script>
<script>
$(document).ready(function() {
// This command is used to initialize some elements and make them work properly
$.material.init();
});
</script>
<script src="js/slick.js"></script>
 </body>
 </html>
