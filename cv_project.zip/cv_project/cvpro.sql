-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2019 at 05:27 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cvpro`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `designation` varchar(45) NOT NULL DEFAULT '',
  `salary` double NOT NULL DEFAULT '0',
  `experience` int(11) NOT NULL DEFAULT '0',
  `qualification` varchar(70) NOT NULL DEFAULT '',
  `skills` varchar(55) DEFAULT NULL,
  `cv` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `designation`, `salary`, `experience`, `qualification`, `skills`, `cv`, `created_at`) VALUES
(1, 'abc', '', 0, 0, '', '', '0.12793300 1558178517TheAvionicsHandbook_Cap_15.pdf', '2019-05-18 11:21:57'),
(2, 'abcd', '', 0, 0, '', '', '0.08111200 1558178677The Days of Small Beginnings.pdf', '2019-05-18 11:24:37'),
(3, 'moteric', '', 0, 0, '', '', '0.26000700 1558178731DESIGN_AND_IMPLEMENTATION_OF_ONLINE_FOOD.pdf', '2019-05-18 11:25:31'),
(4, 'revtouch', '', 0, 0, '', '', '0.79806100 1558178829TheAvionicsHandbook_Cap_15.pdf', '2019-05-18 11:27:09'),
(5, 'revtouch', 'abuja', 150000, 2, 'b.sc', 'computer literate', '0.79239400 1563783348OKEDU KEVIN CV.doc', '2019-07-22 08:15:48');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
`id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `permissions` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `permissions`) VALUES
(1, 'admin', '{"administrator":1}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `salt` varchar(64) NOT NULL,
  `password` varchar(70) NOT NULL,
  `group` int(2) NOT NULL,
  `joined` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `salt`, `password`, `group`, `joined`) VALUES
(16, 'admin', 'admin@admin.com', 'L·°8÷`Ô2—„µÜð¬osjÅ^ÑUw', '66330d6fbc217ad539c09b5d72065d66279c9942561996fae84022a1e402a5dc', 1, '2019-05-18 07:55:23'),
(17, 'patrick', 'patrick@gmail.com', '	 ºÄ_,T/.H€¸DHÖs¼¹q›7¨Y¶Œ#|', 'e6494779b7bce6959684830c8ecd79e4c6dfc73171fa198bf68d92813185995d', 2, '2019-05-18 08:08:19');

-- --------------------------------------------------------

--
-- Table structure for table `user_companies`
--

CREATE TABLE IF NOT EXISTS `user_companies` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `user_cv` varchar(255) NOT NULL,
  `dated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_companies`
--

INSERT INTO `user_companies` (`id`, `user_id`, `company_id`, `user_cv`, `dated`) VALUES
(1, 17, 1, '0.03388400 1558184786TheAvionicsHandbook_Cap_15.pdf', '2019-05-18 13:06:26'),
(2, 17, 1, '0.20357700 1558185357TheAvionicsHandbook_Cap_15.pdf', '2019-05-18 13:15:57'),
(3, 17, 3, '0.82137700 1558185424DESIGN_AND_IMPLEMENTATION_OF_ONLINE_FOOD.pdf', '2019-05-18 13:17:04'),
(4, 17, 1, '0.60061300 1558295117OKEDU KEVIN CV.doc', '2019-05-19 19:45:17'),
(5, 17, 4, '0.93113800 1563817386OKEDU KEVIN CV.doc', '2019-07-22 17:43:06');

-- --------------------------------------------------------

--
-- Table structure for table `user_session`
--

CREATE TABLE IF NOT EXISTS `user_session` (
`id` int(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_companies`
--
ALTER TABLE `user_companies`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_session`
--
ALTER TABLE `user_session`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `user_companies`
--
ALTER TABLE `user_companies`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_session`
--
ALTER TABLE `user_session`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
