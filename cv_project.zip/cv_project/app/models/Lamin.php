<?php 
class Lamin
{
	public $id;
	function __construct()
	{
		$this->_db = DB::getInstance();
	}

	public function getApplicant($table, $column, $where)
	{
		return $eg = $this->_db->select($column, $table, array($where, '=', $this->id))->results();
		//print_r($eg);
		//return $this->_db->get($table, array($where, '=', $this->id))->results();
	}

	public function uploadCV($table, $fields = [])
	{
		if (!$this->_db->insert($table, $fields)) {
			throw new Exception("Error Processing Request", 1);
		}
	}

	public function pager($table,$pages)
	{
		return $this->_db->paginate($table,$pages)->results();
	}

}