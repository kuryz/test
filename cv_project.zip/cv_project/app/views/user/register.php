<?php require_once SITE_ROOT.'/views/share/nav.php'; 

if (Input::exists()) {
	if(Token::check(Input::get('token'))){

	$validate = new Validate();
	$validation = $validate->check($_POST, array(
		'name' => array(
			'required' => true,
			'min' => 4
		),
		'email' => array(
			'required' => true,
			'unique' => 'users'
		),
		'password' => array(
			'required' => true,
			'min' => 6
		),
		'password_confirmation' => array(
			'required' => true,
			'matches' => 'password'
		)
	));
	if (!$validation->passed()) {
		foreach ($validation->errors() as $error) {
			echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning panel">'.$error."</div></div>";
		}
	}else{
		// Redirect::to('postregister');
		Auth::postregister();
	}
}
}
	
	?>

<div class="container col-md-6 col-md-offset-3">
	<div class="well fj-well">
		<form class="form-horizontal" method="post">
		<fieldset>
			<legend>Register</legend>
			
			<div class="form-group">
				<label for="name" class="col-lg-2 control-label">Fullname<i class="fa fa-user"></i></label>
				<div class="col-lg-10">
					<input type="text" class="form-control" id="name" placeholder="" name="name">
				</div>
			</div>
			<div class="form-group">
				<label for="email" class="col-lg-2 control-label">Email <i class="fa fa-envelope"></i></label>
				<div class="col-lg-10">
					<input type="email" class="form-control" id="email" placeholder="" name="email">
				</div>
			</div>
			<div class="form-group">
				<label for="password" class="col-lg-2 control-label">Password<i class="fa fa-lock"></i></label>
				<div class="col-lg-10">
					<input type="password" class="form-control" name="password" placeholder="">
				</div>
			</div>
			<div class="form-group">
				<label for="password" class="col-lg-2 control-label">Confirm Password<i class="fa fa-lock"></i></label>
				<div class="col-lg-10">
					<input type="password" class="form-control" name="password_confirmation" placeholder="">
				</div>
			</div>
			<input type="hidden" name="token" value="<?=Token::generate();?>">
			<div class="form-group">
				<div class="col-lg-10 col-lg-offset-2">
				<button type="reset" class="btn btn-raised btn-default">Cancel</button>
				<button type="submit" class="btn btn-raised btn-primary">Submit</button>
				</div>
			</div>
		</fieldset>
		</form>
	</div>
</div>