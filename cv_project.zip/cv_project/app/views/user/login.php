<?php 
$title='Login';
require_once SITE_ROOT.'/views/share/nav.php'; 

if (Session::exists('home')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-primary">'.Session::flash('home').'</div></div>';
}
if (Input::exists()) {
	if(Token::check(Input::get('token'))){

	$validate = new Validate();
	$validation = $validate->check($_POST, array(
		'email' => array(
			'required' => true
		),
		'password' => array(
			'required' => true,
			'min' => 6
		)
	));
	if (!$validation->passed()) {
		foreach ($validation->errors() as $error) {
			echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning panel">'.$error."</div></div>";
		}
	}else{
		Auth::postLogin();
	}
}
}
?>

<div class="container col-md-6 col-md-offset-3">
	<div class="well fj-well">
		<form class="form-horizontal" method="post">
			<fieldset>
				<legend>Login</legend>
				<div class="form-group">
					<label for="email" class="col-lg-2 control-label">Email</label>
					<div class="col-lg-10">
						<input type="email" class="form-control" id="email" name="email">
					</div>
				</div>
				<div class="form-group">
					<label for="password" class="col-lg-2 control-label">Password</label>
					<div class="col-lg-10">
						<input type="password" class="form-control" name="password">
					</div>
				</div>
				<div class="checkbox">
					<label>
					<input type="checkbox" name="remember" > Remember Me?
					</label>
				</div>
				<input type="hidden" name="token" value="<?=Token::generate();?>">
				<div class="form-group">
					<div class="col-lg-10 col-lg-offset-2">
						<button type="submit" class="btn btn-raised btn-primary">Login</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>