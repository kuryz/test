<?php
$title='Applicant';
require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn() || !$user->hasPermission('administrator')) die(print('<script>window.location.href="./";</script>'));?>

<div class="container">
	<div class="row">
		<div class="col-sm-8 col-md-offset-2 mb-1">
			<div class="well fj-well">
				<table class="table table-bordered">
					<tr>
						<th>Names</th>
						<th>CVs</th>
						<th>Dated Entered</th>
						<th>Action</th>
					</tr>
					<tbody>
						<?php foreach($data['appls'] as $applicant => $key): ?>
							<?php if($key->group > 1): ?>
							<tr>
								<td><?=ucwords($key->name)?></td>
								<td><?=ucwords('CVs')?></td>
								<td><?=ucwords($key->joined)?></td>
								<td><a href="single-all-out/<?=$key->id?>">View</a></td>
							</tr>
							<?php endif; ?>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		
		<div class="clearfix"></div>		
	</div>
</div>
