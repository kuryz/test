<?php require_once SITE_ROOT.'/views/share/nav.php'; 

if (Session::exists('home')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-primary">'.Session::flash('home').'</div></div>';
}
if (Input::exists()) {
	if(Token::check(Input::get('token'))){

	$validate = new Validate();
	$validation = $validate->check($_POST, array(
		'email' => array(
			'required' => true
		),
		'password' => array(
			'required' => true,
			'min' => 6
		)
	));
	if (!$validation->passed()) {
		foreach ($validation->errors() as $error) {
			echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning">'.$error."</div></div>";
		}
	}else{
		
	}
}
}
?>

<div class="container col-md-6 col-md-offset-3">
	<div class="well well bs-component">
		<form class="form-horizontal" method="post">
			<fieldset>
				<legend>Create</legend>
				<div class="form-group">
					<label for="title" class="col-lg-2 control-label">Title</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="title" name="title">
					</div>
				</div>
				<div class="form-group">
					<label for="category" class="col-lg-2 control-label">Category</label>
					<div class="col-lg-10">
						<select class="form-control" id="category" name="category" multiple="">
							<option>test</option>
						</select>
						<!-- <input type="text" class="form-control"> -->
					</div>
				</div>
				<div class="form-group">
					<label for="file" class="col-lg-2 control-label">File Url</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="file" name="file_url">
					</div>
				</div>

				<input type="hidden" name="token" value="<?=Token::generate();?>">
				<div class="form-group">
					<div class="col-lg-10 col-lg-offset-2">
						<button type="submit" class="btn btn-raised btn-primary">Create</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>