<?php
$title='Scan CV';
require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn() || !$user->hasPermission('administrator')) die(print('<script>window.location.href="./";</script>'));?>

<div class="container">
	<div class="row">
		<div class="col-sm-8 col-md-offset-2 mb-1">
			<div class="well fj-well">
				<table class="table table-responsive">
					<tr>
						<th colspan="5" class="text-center"><?=ucwords($data['applicant'][0]->name)?></th>
					</tr>
					<tr>
						<th>CVs</th>
						<th>Company</th>
						<th>Action</th>
						<th>Company CV</th>
						<th>Date entered</th>
					</tr>
					<tbody>	
						<?php /*(ereg('.doc', $key->user_cv)) ? '<i class="fa fa-file-word-o"></i>' : (ereg('.pdf', $key->user_cv)) ? '<i class="fa fa-file-pdf-o"></i>' : 'Failed'*/
						 foreach($data['applicant'] as $app => $key): ?>
							<tr>
								<td><?php 
								if(ereg('.doc', $key->user_cv)){echo '<i class="fa fa-file-word-o"></i>';}
								else if(ereg('.pdf', $key->user_cv)){echo '<i class="fa fa-file-pdf-o"></i>';}
								else echo 'Failed';
								?>
								</td>
								<td><?=ucwords($key->cname)?></td>
								<td><a href="scan-cv/<?=$key->user_cv?>">Scan</a></td>
								<td><?php 
								if(ereg('.doc', $key->cv)){echo '<i class="fa fa-file-word-o"></i>';}
								else if(ereg('.pdf', $key->cv)){echo '<i class="fa fa-file-pdf-o"></i>';}?></td>
								<td><?=$key->dated?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
		
		<div class="clearfix"></div>		
	</div>
</div>
