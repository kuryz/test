<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn() || !$user->hasPermission('administrator')) die(print('<script>window.location.href="./";</script>')); ?>

<div class="container">
	<div class="row">
		<div class="col-sm-3 mb-1">
			<a href="upload-prefered_cv">
				<div class="card mx-auto btn-danger" id="well">
				<i class="fa fa-pencil fa-2x"></i>
				Upload CV
				</div>
			</a>
		</div>
		<div class="col-sm-3 mb-1">
			<a href="view-applicants">
				<div class="card mx-auto btn-primary" id="well">
				<i class="fa fa-eye fa-2x"></i>
				View Applicants
				</div>
			</a>
		</div>
		<div class="col-sm-3 mb-1">
			 <div class="dropdown">
			  <div class="card btn-warning mx-auto dropdown-toggle" role="button" id="menu1" data-toggle="dropdown"><i class="fa fa-question fa-2x"></i> Test Questions
			  </div>
			  <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
			    <li role="presentation"><a role="menuitem" href="apptitude-test">Apptitude Test</a></li>
			    <li role="presentation" class="divider"></li>
			    <li role="presentation"><a role="menuitem" href="#">Personality Test</a></li>
			  </ul>
			</div> 
		</div>
		<div class="clearfix"></div>		
	</div>
</div>
