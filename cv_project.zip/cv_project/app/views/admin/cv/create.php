<?php
$title='Upload CV';
require_once SITE_ROOT.'/views/share/nav.php'; 

if (Session::exists('admin')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-primary panel">'.Session::flash('admin').'</div></div>';
}
if (Input::exists()) {
	if(Token::check(Input::get('token'))){

	$validate = new Validate();
	$validation = $validate->check($_POST, array(
		'company' => array(
			'required' => true
		),
		'designation' => array(
			'required' => true
		),
		'salary' => array(
			'required' => true
		),
		'experience' => array(
			'required' => true
		),
		'qualification' => array(
			'required' => true
		),
		'skills' => array(
			'required' => true
		)
	));
	if (!$validation->passed()) {
		foreach ($validation->errors() as $error) {
			echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning">'.$error."</div></div>";
		}
	}else{
		Admin::upload_cv();
	}
}
}
?>

<div class="container col-md-6 col-md-offset-3">
	<div class="well fj-well">
		<form class="form-horizontal" method="post" enctype="multipart/form-data">
			<fieldset>
				<legend>Upload Company's Preferred CV</legend>
				<div class="form-group">
					<label for="company" class="col-lg-2 control-label">Company</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="company" name="company">
					</div>
				</div>
				<div class="form-group">
					<label for="designation" class="col-lg-2 control-label">Work Desination</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="designation" name="designation">
					</div>
				</div>
				<div class="form-group">
					<label for="salary" class="col-lg-2 control-label">Work Salary</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="salary" name="salary">
					</div>
				</div>
				<div class="form-group">
					<label for="xperi" class="col-lg-2 control-label">Work Experience</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="xperi" name="experience">
					</div>
				</div>
				<div class="form-group">
					<label for="qualification" class="col-lg-2 control-label">Work Qualification</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="qualification" name="qualification">
					</div>
				</div>
				<div class="form-group">
					<label for="skills" class="col-lg-2 control-label">Skills</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="skills" name="skills">
					</div>
				</div>
				<div class="">
					<label for="file" class="col-lg-2 control-label"> Upload P. CV</label>
					<div class="col-lg-10">
						<input type="file" class="" id="file" name="file">
					</div>
				</div>

				<input type="hidden" name="token" value="<?=Token::generate();?>">
				<div class="form-group">
					<div class="col-lg-10 col-lg-offset-2">
						<button type="submit" class="btn btn-raised btn-primary">Create</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>