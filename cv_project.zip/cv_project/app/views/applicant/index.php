<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn()) die(print('<script>window.location.href="./";</script>'));?>

<div class="container">
	<div class="row">
		<div class="col-sm-3 mb-1">
			<a href="upload-my-cv">
				<div class="card mx-auto btn-danger" id="well">
				<i class="fa fa-pencil fa-2x"></i>
				Upload Your CV
				</div>
			</a>
		</div>
		<div class="col-sm-3 mb-1">
			<a href="">
				<div class="card mx-auto btn-primary" id="well">
				<i class="fa fa-book fa-2x"></i>
				Take Aptitude Test
				</div>
			</a>
		</div>
		<div class="col-sm-3 mb-1">
			<a href="">
				<div class="card mx-auto btn-warning" id="well">
				<i class="fa fa-edit fa-2x"></i>
				Create Project
				</div>
			</a>
		</div>
		<div class="clearfix"></div>		
	</div>
</div>