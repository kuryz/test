<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn()) die(print('<script>window.location.href="./";</script>'));

if (Session::exists('comp')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-primary panel">'.Session::flash('comp').'</div></div>';
}
if (Input::exists()) {
	if(Token::check(Input::get('token'))){

	$validate = new Validate();
	$validation = $validate->check($_POST, array(
		'company_id' => array(
			'required' => true
		)
	));
	if (!$validation->passed()) {
		foreach ($validation->errors() as $error) {
			echo '<div class="container col-sm-6 col-sm-offset-3"><div class="alert alert-warning">'.$error."</div></div>";
		}
	}else{
		Applicant::postcvpost();
	}
}
}?>

<div class="container">
	<div class="row">
		<div class="col-sm-8 col-md-offset-2">
			<div class="well fj-well">
				<form class="form-horizontal" method="post" enctype="multipart/form-data">
					<fieldset>
						<legend>Upload</legend>
						<div class="form-group">
							<label for="title" class="col-lg-2 control-label"><?=ucwords($data['user']->data()->name)?></label>
							<div class="col-lg-10">
								<input type="hidden" class="form-control" id="title" name="user" value="<?=$data['user']->data()->id?>">
							</div>
						</div>
						<div class="form-group">
							<label for="company" class="col-lg-2 control-label">Company</label>
							<div class="col-lg-10">
								<select class="form-control" id="company" name="company_id">
									<option selected="">--Choose the company--</option>
									<?php foreach($data['companys'] as $company => $key): ?>
										<option value="<?=$key->id?>"><?=ucwords($key->name)?></option>
									<?php endforeach; ?>
								</select>
								<!-- <input type="text" class="form-control"> -->
							</div>
						</div>
						<div class="">
							<label for="file" class="col-lg-2 control-label">File</label>
							<div class="col-lg-10">
								<input type="file" class="" id="file" name="file">
							</div>
						</div>

						<input type="hidden" name="token" value="<?=Token::generate();?>">
						<div class="form-group">
							<div class="col-lg-10 col-lg-offset-2">
								<button type="submit" class="btn btn-raised btn-primary">Upload</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
		
		<div class="clearfix"></div>		
	</div>
</div>
