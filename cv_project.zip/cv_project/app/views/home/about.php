<?php require_once SITE_ROOT.'/views/share/nav.php'; ?>

<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<div class="well">you are <?=$data['age']?> year old, ur name is <?=$data['name']?>
		<h1 class="text-center"><u>About Us</u></h1>
			<h3>WHO WE ARE?</h3>
			<p>Welcome Researchers, we are reputable online platform poised with the drive to provide All Undergraduate, Post Graduate Diploma, Masters, and Doctorate Students with quality research topics and materials in their various areas of specialization. For further information, <a href="contact">contact us</a></p>
			<b>Help Desk: +23480 3063 3316, +2347060981706, +23470 3570 7836</b><br><br>

			<img src="img/reli.jpg">
			<h3>TRUSTED DELIVERY</h3>

			<p class="text-danger">After payment confirmation, we deliver the material to your email within 15-30 mins (this depends on how fast we get the confirmation).</p>

			<h3>OUR CREDIBILITY.</h3>

			<p>In Ckresearch Project Online Community, we remain focus and are well driven by sincerity and commitment towards serving our esteemed clients which enable our track records speak high volume. Our Platform has earned a good level of online reputation even with an encouraging number of referrals. Our success story is founded on positive success feedbacks from our satisfied clients.</p>


			<h3>QUALITY ASSURANCE</h3>
			<p>ALL RESEARCH MATERIALS FOUND ON THIS SITE ARE RECENTLY RESEARCHED, SUPERVISED AND APPROVED BY QUALIFIED LECTURERS BOTH WITHIN AND OUTSIDE UNIVERSITIES IN NIGERIA WHO ARE INTELLECTUAL AUTHORITIES IN THEIR VARIOUS FIELDS OF STUDY.</p>

			<small class="text-center">Thanks for choosing ckresearchprojects. (...Please refer www.ckprojectsresearch.com to your friends and families too)</small>
		</div>
	</div>
	</div>
</div>
