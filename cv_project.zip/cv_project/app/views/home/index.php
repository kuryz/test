<?php require_once SITE_ROOT.'/views/share/nav.php'; ?>

<div class="container">
    <div class="col-md-8 col-md-offset-2">
  <div class="row">
      <div class="well fj-well">
      <h5 class="text-center"><b>Personality Prediction System Through CV analysis</b></h5>
      <div class="form-group mb-3">
        <img src="img/bg_1.jpg" class="img img-responsive">
      </div>
      <center><?php 
        if($user->isLoggedIn() && !$user->hasPermission('administrator')){
          echo '<a href="upload-my-cv" class="btn btn-default btn-raised">Upload</a>';
        }elseif($user->isLoggedIn() && $user->hasPermission('administrator')){
          echo '<a href="upload-prefered_cv" class="btn btn-default btn-raised">Upload prefered CV</a>';
        }else{echo '<a href="login" class="btn btn-default btn-raised">Login</a>';}?>
      </center>
    </div>

    

  </div>
</div>
</div>