<?php 
define('SITE_ROOT', __DIR__);