<?php 
/**
 * 
 */
class Admin extends Controller
{
	
	function __construct()
	{
		$this->file = $this->model('File');
		$this->applicant = $this->model('Lamin');
	}
	public function index()
	{
		return $this->view('admin/index');
	}

	public function applicants()
	{
		$applicants = $this->applicant->pager('users', 5);
		$appls = $applicants['data'];
		$total = $applicants['total'];
		$per_page = $applicants['pages'];
		//print_r($appl);
		return $this->view('admin/applicants/index', compact('appls','total','per_page'));
	}

	public function applicant_single($id='')
	{
		$this->applicant->id = $id;
		$applicant = $this->applicant->getApplicant('user_companies,users,companies', 'users.name,users.id,user_companies.user_cv,user_companies.company_id,companies.name AS cname,companies.id AS cid,cv,dated','user_companies.user_id = users.id AND companies.id=user_companies.company_id AND user_companies.user_id');
		//print_r($applicant);
		return $this->view('admin/applicants/single_index',compact('applicant'));
	}

	public function cv()
	{
		return $this->view('admin/cv/create');
	}

	public function upload_cv()
	{
		$file = Input::hasFile('file');
		$file_name = $this->file->fileName($file);
		$ext = $this->file->fileExt($file);
		if($ext == 'application/pdf' || $ext == 'application/msword') {
			$custom_file_name = $this->file->move_to($file,'docs/');
			$this->applicant->uploadCV('companies', array(
				'cv' => $custom_file_name,
				'name' => Input::get('company'),
				'designation' => Input::get('designation'),
				'salary' => Input::get('salary'),
				'skills' => Input::get('skills'),
				'qualification' => Input::get('qualification'),
				'experience' => Input::get('experience')
			));
			Session::flash('admin', 'Created successfully');
			Redirect::to('upload-prefered_cv');
		}
	}
}