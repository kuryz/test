<?php 

class Home extends Controller 
{
	public function __construct()
	{
		$this->user = $this->model('User');
	}

	public function index()
	{		
		$this->view('home/index');
	}

	public function contact()
	{
		return $this->view('home/contact');
	}

	public function about($name='',$age)
	{
		$this->user->age = $age;
		$this->user->name  = $name;
		$this->view('home/about', compact('name','age'));
	}
}