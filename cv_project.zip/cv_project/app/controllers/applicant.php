<?php 

class Applicant extends Controller
{
	function __construct()
	{
		$this->_db = DB::getInstance();
		$this->file = $this->model('File');
	}
	public function index()
	{
		return $this->view('applicant/index');
	}

	public function postcvindex()
	{
		$user = new User;
		$companys = $this->_db->get('companies')->results();
		//var_dump($companys);
		return $this->view('applicant/cv/create', compact('companys','user'));
	}
	public function postcvpost()
	{
		$file = Input::hasFile('file');
		$user_id = Input::get('user');
		$company_id = Input::get('company_id');
		if(is_numeric($company_id)){
			$custom_file_name = $this->file->move_to($file,'docs/');
			$this->_db->insert('user_companies', array(
				'user_cv' => $custom_file_name,
				'company_id' => $company_id,
				'user_id' => $user_id
			));
			Session::flash('comp', 'Successful');
			Redirect::to('upload-my-cv');
		}else{
			Session::flash('comp', 'Choose preferred company');
			Redirect::to('upload-my-cv');
		}
		//print_r($file);
	}
}