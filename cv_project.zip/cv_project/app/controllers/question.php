<?php
class Question extends Controller
{
	function __construct()
	{
		$this->_db = DB::getInstance();
	}

	public function app_test()
	{
		return $this->view('question/');
	}
}