<?php 


class About extends Controller 
{
	/*public function __construct()
	{
		$this->user = $this->model('User');
	}*/

	public function index($name = '')
	{
		$this->view('home/about');
	}
	
}