<?php 
/**
 * FJT Paginator class
 */
class Pagination
{
	public $itemsPerPage;
    public $range;
    public $currentPage;
    public $total;
    public $textNav;
    public $itemSelect;
    private $_navigation;      
    private $_link;
    private $_pageNumHtml;
    private $_itemHtml;
	
	function __construct()
    {
        //set default values
        $this->range        = 5;
        $this->currentPage  = 1;       
        $this->total        = 0;
        $this->textNav      = false;
        $this->itemSelect   = array(5,25,50,100,'All');        
        //private values
        $this->_navigation  = array(
                'next'=>'Next',
                'pre' =>'Pre',
                'ipp' =>'Item per page'
        );         
        $this->_link         = filter_var($_SERVER['REQUEST_URI'], FILTER_SANITIZE_STRING);
        $this->_pageNumHtml  = '';
        $this->_itemHtml     = '';
    }

	public function render($total,$per_page)
    {
        $this->total = $total;
        $this->itemsPerPage = $per_page;
        $link = explode('?', trim($this->_link));
        unset($link[1]);
        $this->_link = $link[0];
        //get current page
        if(isset($_GET['page'])){
            $this->currentPage  = $_GET['page'];
            //echo $this->total;    
        }          
        //get page numbers
       return $this->_pageNumHtml = $this->_getPageNumbers();
    }

    private function  _getPageNumbers()
    {
        $html  = '<ul class="pagination">';
        //previous link button
        if(($this->currentPage>1)){
            $html.= '<li><a href="'.$this->_link .'?page='.($this->currentPage-1).'"';
            $html.= '>'.$this->_navigation['pre'].'</a></li>';
        }
        //center link
        $html.='<li class="active"><a href="'.$this->_link .'?page='.$this->currentPage.'">'.$this->currentPage.'</a></li>';
        //next link button
        if(($this->currentPage<$this->itemsPerPage)){
            $html.= '<li><a href="'.$this->_link .'?page='.($this->currentPage+1).'"';
            $html.= '>'.$this->_navigation['next'].'</a></li>';
        }
        $html .= '</ul>';
        return $html;
    }
}