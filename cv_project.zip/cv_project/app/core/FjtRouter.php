<?php 
/*
FJT router.
 */
class FjtRouter
{
	private $_uri = array(), $_action = array();
	protected $par = array();

	public function go($uri, $action)
	{
		$this->_uri[] = '/'.trim($uri, '/');
		//print_r($a);
		if ($action != null && is_string($action)) {
			$a = explode('@', filter_var($action, FILTER_SANITIZE_URL));
			$this->_action[] = $a;
		}else if(is_callable($action)){
			$this->_action[] = $action;
		}
	}

	public function submit()
	{
		$uriGetParam = isset($_GET['url']) ? '/' .$_GET['url'] : '/';
		//echo "<br>";
		foreach ($this->_uri as $key => $value) {
			//echo $value."<br>";
			$patt =preg_match("/:[a-z]|[0-9]$/", $value);
			if ($patt) {
				$pos = str_replace('/:', '/', $value);
				$r=explode('/:', ltrim($value,'/'));$rq=explode('/', trim($uriGetParam, '/'));

				if(count($rq) == count($r)){
					if(is_array($this->_action[$key])){
						$useAction = $this->_action[$key];
						unset($rq[0]);
						$app = new App;
						$app->controller = $useAction[0];
						$app->method = $useAction[1];
						$this->par = $rq ? array_values($rq) : [];
						$app->params = $this->par;
						$app->done();
					}
				}
			}
			/*check if there is a match*/
			if (preg_match("#^$value$#", $uriGetParam)) {
				//echo "<br>match!<br>";
				// echo $key;
				if(is_array($this->_action[$key])){
					$useAction = $this->_action[$key];
					$app = new App;
					$app->controller = $useAction[0];
					$app->method = $useAction[1];
					$app->done();
					// print_r($useAction);
				}else{
					call_user_func($this->_action[$key]);
				}
			}
		}
	}
}