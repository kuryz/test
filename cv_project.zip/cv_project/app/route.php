<?php 

 $route = new FjtRouter;
/*$route->go('/', function(){
	echo "Hello this is the work of the Holy Spirit";
});*/
$route->go('/', 'home@index');
$route->go('/login', 'auth@login');
$route->go('/register', 'auth@register');
$route->go('/postsignup', 'auth@postregister');
$route->go('/about/:id/:we', 'home@about');
$route->go('/contact', 'home@contact');
$route->go('/logout', 'auth@logout');

$route->go('/candidates', 'applicant@index');
$route->go('/upload-my-cv', 'applicant@postcvindex');

$route->go('/admin', 'admin@index');
$route->go('/upload-prefered_cv', 'admin@cv');
$route->go('/view-applicants', 'admin@applicants');
$route->go('/single-all-out/:id', 'admin@applicant_single');
$route->go('/apptitude-test', 'question@app_test');

// echo "<pre>";
// print_r($route);
$route->submit();