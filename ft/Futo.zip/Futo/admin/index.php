<?php
session_start();
include 'include/nav.php'; ?>

<div class="col-md-6 col-md-offset-3 intel">
	<?php $tonye = $_SESSION['tok'] = sha1(md5(uniqid(mt_rand(),true))); ?>
	<form action="log.php" method="post">
		<div class="form-group">
			<input type="text" name="username" class="form-control" placeholder="enter your username">
		</div>
		<div class="form-group">
			<input type="password" name="password" class="form-control">
		</div>
		<input type="hidden" name="admin" value="<?php echo($tonye); ?>">
		<div class="col-md-4 col-md-offset-4"><input type="submit" class="btn btn-primary btn-block" name="yes" value="Submit"></div>
	</form>
</div>
<?php /*echo sha1(md5('samuel'));*/ 
include 'include/butt.php' ?>
