<?php
session_start();
include 'include/start.php'; 

if (isset($_GET['pid']) && isset($_GET['ref'])) {
	$ordersId = $_GET['pid'];
	$userId = $_GET['ref'];
	$db->query("UPDATE orders SET done=1 WHERE id='$ordersId'");
	header('location:single_view.php?ref='.$userId);
}
?>