<?php
session_start();
include 'include/start.php'; 
include 'include/nav.php'; 
if((!isset($password)) && (!isset($_SESSION['password']))){die(print('<script>window.location.assign("index.php?er=Login")</script>'));}
?>

<div class="col-md-6 col-md-offset-3 wrap">
	<h1>Add Administrator</h1>
	<form action="add_admin.php" method="post">
		<div class="form-group">
			<input type="text" name="name" class="form-control" placeholder="enter your fullname">
		</div>
		<div class="form-group">
			<input type="text" name="username" class="form-control" placeholder="enter your username">
		</div>
		<div class="form-group">
			<input type="email" name="email" class="form-control" placeholder="enter your email">
		</div>
		<div class="form-group">
			<input type="password" name="password" class="form-control">
		</div>
		
		<div class="col-md-4 col-md-offset-4"><input type="submit" class="btn btn-primary btn-block" name="yes" value="Submit"></div>
	</form>
</div>
<?php /*echo sha1(md5('samuel'));*/ 
include 'include/butt.php' ?>
