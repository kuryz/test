<?php 
session_start();
include 'include/start.php';
$ok = 0;
$msg = '';

if (isset($_GET['ref'])) {
	$id = $_GET['ref'];
	if (!is_numeric($id)) {
		$ok = 1;
		$msg.=' You are tresspassing ';
	}
	if ($ok=0) {
		$db->query("DELETE FROM tblproduct WHERE id='$id'");
		header('location:all_product.php?info=deleted');
	}else{
		header('location:all_product.php?info=error');
	}

}else{
	header('location:all_product.php?info=sorry');
}

?>