	<?php
session_start();
include 'include/start.php'; 
include 'include/nav.php'; 
if((!isset($password)) && (!isset($_SESSION['password']))){die(print('<script>window.location.assign("index.php?er=Login")</script>'));}
?>
<div class="container">
	<div class="well">
		<h1 class="text-center">New Orders</h1>
	</div>
	<div class="col-md-6 col-md-offset-3">
		<table class="table table-bordered">
			<thead>
				<tr>
					<!-- <th>Name</th>
					<th class="text-center">Price</th>
					<th class="text-center">Quantity</th> -->
					<th>Customer</th>
					<th class="text-center">Date</th>
				</tr>
			</thead>
			<tbody>
				<?php $e = $db->query("SELECT * FROM orders, users WHERE orders.user_id=users.id ORDER BY order_at DESC LIMIT 1");
				while ($r=$e->fetch_assoc()) {
				 	
				 		echo '<tr>
				 	
					 		<td><a href="single_view.php?ref='.$r['user_id'].'">'.ucwords($r['full_name']).' </a></td>
					 		<td class="text-center">'.$r['order_at'].'</td>
					 	</tr>';
					 	
				 }
					 	?>
			</tbody>
			
		</table>
	</div>
	
</div>

<?php include 'include/butt.php'; ?>