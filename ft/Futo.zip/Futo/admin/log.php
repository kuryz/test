<?php 
session_start();
include 'include/start.php';

if (isset($_POST['yes'])) {
	if (isset($_SESSION['tok']) && $_POST['admin'] == $_SESSION['tok']) {
		$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
		$password= $_POST['password'];
    	$password=sha1(md5($password));

    	$log_query=$db->query("SELECT id, name FROM admins WHERE username='$username' AND password ='$password'");
    	if ($log_query->num_rows>0) {
    		$_SESSION['password'] = $password;
    		header("location:dashboard.php");
    	}else{
    		header("location:index.php?error=Invalid entry");
    	}
	}else{
		echo "session not set";
	}
}
 ?>