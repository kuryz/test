<?php 
session_start();
include 'include/start.php';
$ok = 0;
$msg = '';

if (isset($_POST['product'])) {
	$productName = $_POST['name'];
	$productPrice = $_POST['price'];
	$productDesc  = $_POST['desc'];
	$productCategory  = $_POST['category'];

	if ($productName == '' && $productDesc == '' && $productPrice == '' && $productCategory == '') {
		$ok = 1;
		$msg.' No values ';
	}

	$unique=microtime();
	if($_FILES["file"]["error"] != 0){$ok=1; $msg.=' no upload ! ';}
	$photo=$_FILES['file']['name'];
	$types = array('image/jpeg','image/gif','image/png');
	if (in_array($_FILES['file']['type'], $types)==false) {$ok=1; $msg.=' invalid file type ! ';}
	$photo=$unique.$photo;
	$target='prod/'.$photo;

	if ($ok == 0) {
		move_uploaded_file($_FILES['file']['tmp_name'],$target);
		$db->query("INSERT INTO tblproduct(name, image, price, cat_id)VALUES('$productName', '$target', '$productPrice', '$productCategory')");
		header('location:add_product.php?msg=Product inserted successfully');
	}else{
		header('location:add_product.php?er='.$msg);
	}

}else{
	header('location:add_product.php?er=fill and submit please');
}
?>