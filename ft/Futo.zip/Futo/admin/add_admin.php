<?php 
session_start();
include 'include/start.php';

if (isset($_POST['yes'])) {
	$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
	$password= $_POST['password'];
	$password=sha1(md5($password));

    $log_query=$db->query("SELECT id, name FROM admins WHERE username='$username' AND password ='$password'");
    if ($log_query->num_rows>0) {
       header('location:profile.php?error=Existing');
    }else{
	   $db->query("INSERT INTO admins(name, password, username, email)VALUES('$name', '$password', '$username', '$email')");
       header('location:profile.php?error=Inserted');
	}
}else{
	echo "session not set";
}

 ?>