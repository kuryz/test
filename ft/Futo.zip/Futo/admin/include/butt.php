</body>
<script type="text/javascript" src="../bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="../bootstrap/js/bootstrap.js"></script>
</html>