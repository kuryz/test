<?php 
$db = new mysqli('localhost', 'root', '', 'futofarm');
if ($db->connect_error) {die("opps, try again later." );} 

if (isset($_SESSION['password'])){
	
$password=$_SESSION['password'];
 $admin =$db->query("SELECT * FROM admins WHERE password='$password'");
 while ($row = $admin->fetch_assoc()) {
 	# code...
 	$fullname=$row['name'];
 	$password=$row['password'];
 }
}
?>