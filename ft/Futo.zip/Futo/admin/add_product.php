<?php
session_start();
include 'include/start.php'; 
include 'include/nav.php'; 
if((!isset($password)) && (!isset($_SESSION['password']))){die(print('<script>window.location.assign("index.php?er=Login")</script>'));}
?>
<div class="container">
	<div class="well">
		<h1 class="text-center">Add A Product</h1>
	</div>
	<div class="col-md-6">
		<?php if (isset($_GET['er'])) {
			echo '<div class="alert alert-danger">'.$_GET['er'].'</div>';
		}if (isset($_GET['msg'])) {
			echo '<div class="alert alert-success"><center>'.$_GET['msg'].'</center></div>';
		} ?>
		<form action="add_action.php" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<input type="text" name="name" class="form-control" placeholder="Enter product name" required="true">
			</div>
			<div class="form-group">
				<input type="file" name="file" class="form-control">
			</div>
			<div class="form-group">
				<input type="text" name="price" class="form-control" placeholder="Enter product price" required="true">
			</div>
			<div class="form-group">
				<!-- <input type="text" name="desc" class="form-control" placeholder="Enter product description" required="true"> -->
				<textarea name="desc" rows="3" class="form-control"></textarea>
			</div>
			<div class="form-group">
				<select name="category" class="form-control" required="true">
					<option value="">--Select Category--</option>
					<option value="1">Livestock</option>
					<option value="2">Tuber</option>
					<option value="3">Vegetable</option>
				</select>
			</div>
			<div class="form-group">
				<input type="submit" name="product" class="btn btn-primary" value="submit">
			</div>
		</form>
		<a href="dashboard.php" class="btn btn-warning pull-right">Back</a>
	</div>
	
</div>

<?php include 'include/butt.php'; ?>