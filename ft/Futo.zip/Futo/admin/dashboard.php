<?php
session_start();
include 'include/start.php'; 
include 'include/nav.php'; 
if((!isset($password)) && (!isset($_SESSION['password']))){die(print('<script>window.location.assign("index.php?er=Login")</script>'));}
?>
<div class="container">
	<div class="jumbotron">
		<h1 class="text-center">Welcome</h1>
	</div>
	<div class="col-md-6">
		<div class="list-group">
	  		<div class="list-group-item">
				<div class=""><i class=""></i></div>
					<a href="add_product.php" class="btn btn-primary btn-lg btn-block">Add Product</a>
			</div>
		</div>
		<div class="list-group">
	  		<div class="list-group-item">
				<div class=""><i class=""></i></div>
					<a href="all_product.php" class="btn btn-primary btn-lg btn-block">All Products</a>
			</div>
		</div>
		<div class="list-group">
	  		<div class="list-group-item">
				<div class=""><i class=""></i></div>
					<a href="view_orders.php" class="btn btn-primary btn-lg btn-block">View Orders</a>
			</div>
		</div>
	</div>
	
</div>

<?php include 'include/butt.php'; ?>