<?php
session_start();
include 'include/start.php'; 
include 'include/nav.php'; 
if((!isset($password)) && (!isset($_SESSION['password']))){die(print('<script>window.location.assign("index.php?er=Login")</script>'));}
?>
<div class="container">
	<div class="well">
		<h1 class="text-center">All Product</h1>
	</div>
	<div class="col-md-6 col-md-offset-3">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th class="text-center">Price</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			<?php $tb = $db->query("SELECT * FROM tblproduct");
			while ($row=$tb->fetch_assoc()) {
			 	echo '
				<tbody>
				<tr>
					<td>'.ucfirst($row['name']).'</td>
					<td class="text-center">'.$row['price'].'</td>
					<td class="text-center"><a href="edit.php?ref='.$row['id'].'" class="btn btn-warning btn-sm">Edit</a> <a href="delete.php?ref='.$row['id'].'" class="btn btn-danger btn-sm">Delete</a></td>
				</tr>
				</tbody>';
			 } ?>
			
		</table>
		<a href="dashboard.php" class="btn btn-warning">Back</a>
	</div>
	
</div>

<?php include 'include/butt.php'; ?>