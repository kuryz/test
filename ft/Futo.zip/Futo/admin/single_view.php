<?php
session_start();
include 'include/start.php'; 
include 'include/nav.php'; 
if((!isset($password)) && (!isset($_SESSION['password']))){die(print('<script>window.location.assign("index.php?er=Login")</script>'));}
if (isset($_GET['ref'])) {
	$user = $_GET['ref'];
	$e = $db->query("SELECT *, orders.id as pid FROM orders, users WHERE orders.user_id='$user' ORDER BY order_at DESC");
	

?>
<div class="container">
	<div class="well">
		<h1 class="text-center">Orders </h1>
	</div>
	<div class="col-md-6 col-md-offset-3">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Name</th>
					<th class="text-center">Price</th>
					<th class="text-center">Quantity</th>
					
					<th class="text-center">Date</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				while ($r=$e->fetch_assoc()) {
					$w=$r['full_name'];
				 	if ($r['done'] == 0) {
				 		echo '<tr>
				 			<td>'.$r['name'].'</td>
					 		<td class="text-center">'.$r['amt'].'</td>
					 		<td class="text-center">'.$r['quantity'].'</td>
					 		<td class="text-center">'.$r['order_at'].'</td>
					 		<td class="text-center"><a href="check.php?pid='.$r['pid'].'&ref='.$user.'" class="btn btn-sm btn-default">Check</a></td>
					 	</tr>';
					 }else{
					 	echo '<tr>
				 			<td>'.$r['name'].'</td>
					 		<td class="text-center">'.$r['amt'].'</td>
					 		<td class="text-center">'.$r['quantity'].'</td>
					 		<td class="text-center">'.$r['order_at'].'</td>
					 		<td class="text-center"><a href="#" class="btn btn-sm btn-default disabled">Checked</a></td>
					 	</tr>';
					 }
				}
			}?>
			</tbody>
			<?php echo ucwords($w );?>
		</table>
	</div>
	
</div>

<?php include 'include/butt.php'; ?>