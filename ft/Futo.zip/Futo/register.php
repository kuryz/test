<?php include 'includes/nav.php'; ?>

   <div class="col-md-6 col-md-offset-3">
   	<h1>register Our Services</h1>
     <form action="reg.php" method="post">
		<div class="form-group">
			<input type="text" name="fullname" class="form-control" placeholder="enter your fullname">
		</div>
		<div class="form-group">
			<input type="email" name="email" class="form-control" placeholder="enter your email">
		</div>
		<div class="form-group">
			<input type="password" name="password" class="form-control">
		</div>
		<div class="form-group">
			<input type="text" name="phone" class="form-control" placeholder="Enter phone number">
		</div>
		<div class="form-group">
			<input type="text" name="address" class="form-control" placeholder="Enter address">
		</div>
		
		<div class="col-md-4 col-md-offset-4"><input type="submit" class="btn btn-primary btn-block" name="yes" value="Submit"></div>
		<span>You've registered? <a href="login.php">click</a></span>
	</form>
   </div>


<script type="text/javascript" src="bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="cart2.js"></script>
</body>
</html>