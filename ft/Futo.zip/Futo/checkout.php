<?php 
include 'includes/conn.php';
include 'includes/nav.php'; 



?>
<div class="container">
    <div class="row">
        <div class="well">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
        
        <form>
            <table class="table table-bordered">
            
            <tbody id="ou"></tbody>

            </table><button type="submit" class="btn btn-success btn-block">Check Out</button>
        </form>
        
    </div>
    
</div>
<script type="text/javascript" src="bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="cart2.js"></script>
<script type="text/javascript">
    
    function getItems() {
        var str = localStorage.getItem("cart_items")
        Item = JSON.parse(str);
        if (!Item) {
            Item = [];
        }
        console.log(Item); 
    }
getItems();

function listItem() {
    var h = "";
    var v = document.getElementById('ou');
    for (var i in Item) {
        var it = Item[i];
        var n =it;
        
        v.innerHTML += "<input type='text' class='form-control' value='"+n.name+"' disabled><input type='text' class='form-control' value='"+(n.price*n.quantity)+"' disabled><input type='text' class='form-control' value='"+n.quantity+"'>";
    }
}
listItem();
</script>
</body>
</html>