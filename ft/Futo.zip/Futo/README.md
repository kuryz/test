# Futofarmsproject
I used offline bootstrap, you might not be able to view it very well on the web, except u have an offline downloaded bootstrap. Then all the images were saved in a folder called 'img' if you check my html and css you will notice that. When u have downloaded this project save all the images in one folder and name it img. 
github pass: 47493d0d6f936cf59aa0cba4fb101f54




Say, behold He comes, riding on the clouds
Shining like the sun, at the trumpet's call
Lift your voice, (it's) the year of Jubilee
Out of Zion's hill, salvation comes