<?php include 'includes/nav.php'; ?>

   <div class="col-md-6 col-md-offset-3">
   	<h1>Login Our Services</h1>
   	<?php if (isset($_GET['error'])) {
   		echo '<div class="alert alert-danger">'.$_GET['error'].'</div>';
   	} ?>
     <form action="naso.php" method="post">
		<div class="form-group">
			<input type="email" name="email" class="form-control" placeholder="enter your email" autofocus="true">
		</div>
		<div class="form-group">
			<input type="password" name="password" class="form-control">
		</div>
		
		<div class="col-md-4 col-md-offset-4"><input type="submit" class="btn btn-primary btn-block" name="yes" value="Submit"></div>
		<span>You've not registered? <a href="register.php">click</a></span>
	</form>
   </div>


<script type="text/javascript" src="bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="cart2.js"></script>
</body>
</html>