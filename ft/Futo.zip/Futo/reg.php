<?php 
include 'includes/conn.php';

$ok=0;
$error='';

$fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING);
 if(strlen($fullname)<3 || strlen($fullname)>10){$ok=1; $error.="Unsuccessful. Name input must be between 3 and 10 charcters.";}
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
$address = $_POST['address'];
$password=sha1(md5($password));
if (strpbrk($address, "<>{}*\"'")){
	# code legalisation...
	exit("input contains illegal characters.");
}
$phone= filter_input(INPUT_POST, 'phone',FILTER_SANITIZE_NUMBER_INT);
if ($phone == '' && $email == '' && $address == '' && $password == '') {
	$ok = 1;
	$error.=' empty fields ';
}


if ($ok == 0) {
	$db->query("INSERT INTO users(email, password, full_name, address, phone)VALUES('$email', '$password', '$fullname', '$address', '$phone')");
	header('location:login.php');
}else{
	header('location:register.php?error='.$error);
}
?>