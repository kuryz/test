<?php 
session_start();
include 'includes/conn.php';
include 'includes/nav.php'; 



?>
<div class="container">
    <div class="well">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<h1 class="text-center">Livestock</h1></div>
    <div class="row">

        <?php 
        $q = $db->query("SELECT image,price,name FROM tblproduct WHERE cat_id = 1");
        while ($r = $q->fetch_assoc()) {
            $nam = "'".$r['name']."'";
            echo '
            <div class="col-md-4">
                <div class="thumbnail">
                    <img src="img/'.$r['image'].'" class="img">
                    <div class="caption">
                        <h3>'.$r['name'].'</h3>
                        <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut </p>
                        <div class="clearfix">
                            <div class="text-danger price">$'.$r['price'].'</div>
                            <a href="#" class="btn btn-primary btn-sm btn-raised pull-left">View</a>
                            <a href="#" class="btn btn-primary btn-sm btn-raised pull-right" onclick="cart.addItem('.$nam.','.$r['price'].', 1); return false;">Add To Cart</a>
                        </div>
                    </div>
                </div>
            </div>';
        }
         ?>
    </div>
    <div class="well">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<h1 class="text-center">Tuber</h1></div>
    <div class="row">

        <?php 
        $q = $db->query("SELECT image,price,name FROM tblproduct WHERE cat_id = 2");
        while ($r = $q->fetch_assoc()) {
            $nam = "'".$r['name']."'";
            echo '
            <div class="col-md-4">
                <div class="thumbnail">
                    <img src="img/'.$r['image'].'" class="img">
                    <div class="caption">
                        <h3>'.$r['name'].'</h3>
                        <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut </p>
                        <div class="clearfix">
                            <div class="text-danger price">$'.$r['price'].'</div>
                            <a href="#" class="btn btn-primary btn-sm btn-raised pull-left">View</a>
                            <a href="#" class="btn btn-primary btn-sm btn-raised pull-right" onclick="cart.addItem('.$nam.','.$r['price'].', 1); return false;">Add To Cart</a>
                        </div>
                    </div>
                </div>
            </div>';
        }
         ?>
    </div>
    <div class="well">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<h1 class="text-center">Vegetable</h1></div>
    <div class="row">

        <?php 
        $q = $db->query("SELECT image,price,name FROM tblproduct WHERE cat_id = 3");
        while ($r = $q->fetch_assoc()) {
            $nam = "'".$r['name']."'";
            echo '
            <div class="col-md-4">
                <div class="thumbnail">
                    <img src="admin/'.$r['image'].'" class="img">
                    <div class="caption">
                        <h3>'.$r['name'].'</h3>
                        <p class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut </p>
                        <div class="clearfix">
                            <div class="text-danger price">$'.$r['price'].'</div>
                            <a href="#" class="btn btn-primary btn-sm btn-raised pull-left">View</a>
                            <a href="#" class="btn btn-primary btn-sm btn-raised pull-right" onclick="cart.addItem('.$nam.','.$r['price'].', 1); return false;">Add To Cart</a>
                        </div>
                    </div>
                </div>
            </div>';
        }
         ?>
    </div>
    
</div>
<script type="text/javascript" src="bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="cart2.js"></script>
<script type="text/javascript">


</script>
</body>
</html>