<?php 
session_start();
include 'includes/conn.php';

if (isset($_POST['yes'])) {
	
		$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
		$password= $_POST['password'];
    	$password=sha1(md5($password));

    	$log_query=$db->query("SELECT id, full_name FROM users WHERE email='$email' AND password ='$password'");
    	if ($log_query->num_rows>0) {
    		$_SESSION['password'] = $password;
    		header("location:shopping_cart.php");
    	}else{
    		header("location:login.php?error=Invalid entry");
    	}
	
}else{
	echo "session not set";
}
?>