//shoppin cart

function shoppinCart(cartName) {
	this.cartName=cartName;
	this.clearCart=false;
	this.items=[];
	//this loads from localStorage wen initializin
	this.loadItems();
	//this saves to localStorage wen unloadin
	var self=this;
	$(window).unload(function(){
		if (self.clearCart) {
			self.clearItems();
		}
		self.saveItems();
		self.clearCart=false;
	});
	//reload items wen localStorage changes
	$(window).on('storage', function(e){
		if (e.originalEvent.key == self.cartName + '_items' && !self.savingItems) {
			self.loadItems();
		}
	});

}

//load items from localStorage
shoppinCart.prototype.loadItems = function() {
	//empty list
	this.items.splice(0, this.items.length);
	//load from localStorage
	var items = localStorage != null ? localStorage[this.cartName + "_items"] : null;
	if (items != null && JSON != null) {
		try{
			var items=JSON.parse(items);
			for (var i = 0; i < items.length; i++) {
				var item=items[i];
				if(item.name != null && item.name != null && item.price != null && item.quantity != null){
					item=new cartItem(item.name, item.price,item.quantity);
					this.items.push(item);
				}
			}
		}
		catch(err){
			//ignore errors
		}
	}
	//notify listeners of change
	if (this.itemsChanged) {
		this.itemsChanged();
	}
}

//save items to localStorage
shoppinCart.prototype.saveItems = function() {
	if (localStorage != null && JSON != null) {
		localStorage[this.cartName + "_items"]=JSON.stringify(this.items);
	}
}

//adds item to the cart
shoppinCart.prototype.addItem = function(name,price,quantity) {

	quantity=this.toNumber(parseInt(quantity));
	if (quantity!=0) {
		//update qty for existin item
		var found = false;
		for (var i = 0;( (i < this.items.length) && (!found)); i++) {
			var item = this.items[i];
			if (item.name == name) {
				found = true;
				item.quantity = this.toNumber(item.quantity+quantity);
				if (item.quantity<=0) {
					this.items.splice(i,1);
				}
				document.getElementById('qty').innerHTML = this.quantity;
			}
		}
		if (!found) {
			var item = new cartItem(name,price,quantity);
			this.items.push(item);
		}
		//save changes
		this.saveItems();
		qtyCount();
	}
}

//get total price
shoppinCart.prototype.getTotalPrice = function(name) {
	var total=0;
	for (var i = 0; i < this.items.length; i++) {
		var item=this.items[i];
		if (name==null || item.name == name) {
			total+=this.toNumber(item.quantity * item.price);
		}
	}
	return total;
}

//get the totalprice forAll items
shoppinCart.prototype.getTotalCount = function(name) {
	var count=0;
	for (var i = 0; i < this.items.length; i++) {
		var item =this.items[i];
		if (name == null || item.name == name) {
			count += this.toNumber(item.quantity);
		}
	}
	return count;
}

//this clears cart
shoppinCart.prototype.clearItems = function() {
	this.items=[];
	this.saveItems();
	clrCount();
	qtyCount();
}

shoppinCart.prototype.toNumber = function(v) {
	v = v * 1;
	return isNaN(v) ? 0 : v;
}

//items in the cart
function cartItem(name,price,quantity){
	/*this.sku=sku;*/
	this.name=name;
	this.price=price * 1;
	this.quantity=quantity * 1;
}
/*function cartItem(sku,name,price,quantity){
	this.s=sku;
	this.n=name;
	this.p=price * 1;
	this.q=quantity * 1;
}
function shoppinCart(cartname){
	basket={};
	items=[];

basket.cartItem=function(s,n,p,q){
	for (var i = 0; i < items.length; i++) {
		if (items[i].name==item) {
			items[i].count++
			return items[i].count;
		}
	}
	var item = new cartItem(s,n,p,q);
	items.push(item);
	localStorage[cartname]=JSON.stringify(items);
	return 1;
}

return basket;
}*/
var cart = new shoppinCart('cart');
function qtyCount(){
	document.getElementById('qty').innerHTML = cart.getTotalCount();
}
qtyCount();
function clrCount(){
	document.getElementById('ou').innerHTML = "";
}