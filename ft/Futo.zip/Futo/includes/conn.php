<?php 
/*$l='root';
$p='';
try{
    $db = new PDO('mysql:host=localhost;dbname=futofarm',$l,$p);
}catch(PDOException $e){
    echo $e->getMessage();
}
$db->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);*/
$db = new mysqli('localhost', 'root', '', 'futofarm');
if ($db->connect_error) {die("opps, try again later." );} 


if(isset($_SESSION["password"])){
	$user=$_SESSION['password'];
	$q = $db->query("SELECT * FROM users WHERE password ='$user'");
	while ($row=$q->fetch_assoc()) {
		$fname = $row['full_name'];
		$userId = $row['id'];
	}
}

?>