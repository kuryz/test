<?php 
session_start();
include 'includes/conn.php';

$name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
$price= filter_input(INPUT_POST, 'price',FILTER_SANITIZE_NUMBER_INT);
$quantity= filter_input(INPUT_POST, 'quantity',FILTER_SANITIZE_NUMBER_INT);
$n = $_SESSION['name'] = $name;
$p = $_SESSION['price'] = $price;
$q = $_SESSION['quantity'] = $quantity;

if (isset($fname)) {
	$db->query("INSERT INTO orders(user_id, amt, name, quantity)VALUES('$userId', '$p', '$n', '$q')");
	header('location:shopping_cart.php');
}else{
	header('location:login.php');
}
?>