var basket = (function () {
	var basket = {};
	var items = [];

	function addItem(item, cost) {
	
		for (var i = 0; i < items.length; i++) {
			if (items[i].name==item) {
				items[i].count++
				return items[i].count;
			}
		}
		
		items.push({ name: item, price: cost, count: 1 });
		localStorage['cartname']=JSON.stringify(items);
		return 1;
	}

	basket.addItem = function(item, cost) {
		var count = addItem(item, cost);
		console.log("You have " + count + " of " + item + " in your basket.");
	}
	return basket;
})();