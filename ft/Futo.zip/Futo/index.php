<?php include 'includes/nav.php'; ?>

    <div id="home">
      <div class="landing-text">
        <h1>Welcome to FUTOfarms</h1>
        <h3>We offer the best discounts on agro products</h3>
        <center><div class="order"><a href="product.php" class="text-center">Shop Now</a></div></center>
      </div>
    </div>

    <div class="padding">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <img src="img/livestock.jpg">
          </div>
          <div class="col-sm-6 text-center">
            <h2>Livestock category</h2>
            <p class="lead">We sell healthy livestocks (chicken, catfish, cows, pigs, goats etc) shop with us today and find out our available livestocks.</p>
            <a href="#" class="btn btn-default btn-sm">Available Livestocks</a>
          </div>
        </div>
      </div>
    </div>

    <div class="padding">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <img src="img/fruits.jpg">
          </div>
          <div class="col-sm-6 text-center">
            <h2>Fruits/Vegetable Category</h2>
            <p class="lead">We sell good and matured fruits (banana, plantain, pineapple, mango, sugarcane, pumpkin leaf etc.)</p>
            <a href="#" class="btn btn-default btn-sm">Available Fruits/Vegetables</a>
          </div>
        </div>
      </div>
    </div>

    <div class="padding">
      <div class="container">
        <div class="row">
          <div class="col-sm-6">
            <img src="img/other_products.jpg">
          </div>
          <div class="col-sm-6 text-center">
            <h2>Other Products</h2>

            <p class="lead">Our other products include (palm oil, cassava, cassava stem, ogbono, honey etc.)</p>
            <a href="#" class="btn btn-default btn-sm">Other products</a>
          </div>
        </div>
      </div>
    </div><br><br>

    <div id="fixed"></div>


    <footer class="container-fluid text-center">
      <div class="row">
        <div class="col-sm-6">
          <h3>Contact Us</h3>
          <br>
          <h4>futofarms@gmail.com</h4>
        </div>
        <div class="col-sm-4">
          <h3>Connect</h3>
          <a href="#" class="fa fa-facebook"></a>
          <a href="#" class="fa fa-twitter"></a>
          <a href="#" class="fa fa-google"></a>
          <a href="#" class="fa fa-linkedin"></a>
          <a href="#" class="fa fa-youtube"></a>
        </div>
        
      </div>
    </footer>







<script type="text/javascript" src="bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="cart2.js"></script>
</body>
</html>