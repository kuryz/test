<?php 
session_start();
include 'includes/conn.php';
include 'includes/nav.php'; 



?>
<div class="container">
    <div class="row">
        <div class="well">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>
        
        <table class="table table-bordered">
            <thead>
                <th>Item</th>
                <th class="text-center">Price</th>
                <th class="text-center">Quantity</th>
                <th class="text-center">Action</th>
            </thead>
            <tbody id="ou"></tbody>

        </table><!-- <button type="button" class="btn btn-primary btn-block" id="orderBtn">Order All</button> --><button class="btn btn-danger btn-block" onclick="cart.clearItems()">Clear all</button>
    </div>
    
</div>
<script type="text/javascript" src="bootstrap/js/jquery-1.12.3.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="cart2.js"></script>
<script type="text/javascript">

    function getItems() {
        var str = localStorage.getItem("cart_items")
        Item = JSON.parse(str);
        if (!Item) {
            Item = [];
        }
        console.log(Item); 
    }
getItems();

function listItem() {
    var h = 0;
    var v = document.getElementById('ou');
    for (var i in Item) {
        var it = Item[i];
        var n =it;
        
        v.innerHTML += '<td>'+n.name+'</td><td class="text-center">'+(n.price*n.quantity)+'</td><td class="text-center">'+n.quantity+'</td><td class="text-center"><form action="server.php" method="post"><input type="hidden" name="name" value="'+n.name+'" id="name'+h+'"><input type="hidden" name="price" value="'+(n.price*n.quantity)+'" id="price'+h+'"><input type="hidden" name="quantity" value="'+n.quantity+'" id="quantity'+h+'"><button type="submit" class="btn btn-default btn-sm" onclick="trySub('+h+')" id="id'+h+'">Order</button> <button type="button" class="btn btn-danger btn-sm" onclick="trySubb('+h+')" id="id'+h+'">Delete</button></form></td>';
        h=h+1;
    }
}
listItem();


function trySub(a) {
    
    var n = document.getElementById('name'+a).value;
    var p = document.getElementById('price'+a).value;
    var q = document.getElementById('quantity'+a).value;
    alert(n+' is ordered');
    cart.addItem(n, p, -10000000);
}
function trySubb(a) {
    
    var n = document.getElementById('name'+a).value;
    var p = document.getElementById('price'+a).value;
    var q = document.getElementById('quantity'+a).value;
    alert(n+' is deleted');
    cart.addItem(n, p, -10000000);
    window.location='http://localhost/Futo/shopping_cart.php'
}
</script>
</body>
</html>